// -----JS CODE-----

// Get the game objects from the scene
// @input SceneObject character
// @input SceneObject collision
// @input SceneObject collisionImg1
// @input SceneObject collisionImg2
// @input SceneObject collisionImg3
// @input SceneObject bg1
// @input SceneObject bg2
// @input SceneObject gameOverBg
// @input Component.Text scoreText
// @input Component.AudioComponent jump
// @input Component.AudioComponent gameBGM
// @input Component.AudioComponent gameOverBGM


// Variables
var score = 0;
var playing = false;
var randomNumber = 0;
var collisionTimer = 0;

// A function that is called every frame
function update(eventData)
{
    // If the game is active
    if(playing)
    {
        // Set the jump sound active
        script.jump.volume = 0.5;
        
        // Makes a timer
        collisionTimer += eventData.getDeltaTime();
        
        if(collisionTimer >= 1.7)
        {
            // Reset the timer
            collisionTimer = 0;
            
            // Choose a random collision image
            chooseCollision();
        }
        // Update the score
        script.scoreText.text = "" + score;
    
        // Check for collision
        checkCollision();
    }
    // If the game isn't active
    else
    {
        // Set the jump sound inactive
        script.jump.volume = 0;
    }
    
}

// A function that checks for collision between the player and the collision objects
function checkCollision()
{
    // Get the X and Y position of the collision object
    var collisionTransform = script.collision.getTransform();
    var collisionPosition  = collisionTransform.getLocalPosition();
    var collisionPositionX = collisionPosition.x;
    var collisionPositionY = collisionPosition.y;
    
    // Get the X and Y position of the character
    var characterTransform = script.character.getTransform();
    var characterPosition  = characterTransform.getLocalPosition();
    var characterPositionX = characterPosition.x;
    var characterPositionY = characterPosition.y;
    
    // Check if the character is colliding with the collision object on the x axis
    if(collisionPositionX >= -3.8303000926971436 + -0.15 && collisionPositionX <= -3.8303000926971436 + 0.15)
    {
        // Check if the character was jumping while colliding
        // If he wasn't...
        if(characterPositionY < -1.1)
        {
            // Game over
            print("Game over");
            
            // End the game
            gameOver();
        }
        // If he was...
        else
        {
            // Add one point to the score
            score++;
            print("your score: " + score);
        }
    }
}

// This function ends the game and resets it
function gameOver()
{
    // Set the game inactive
    playing = false;
    
    // Reset The score
    score = 0;
    
    // Reset the timer
    collisionTimer = 0;
    
    // Stop all objects from moving
    global.tweenManager.stopTween(script.collision, "collision_move");
    global.tweenManager.stopTween(script.bg1, "bg1_move");
    global.tweenManager.stopTween(script.bg2, "bg2_move");
    
    // Turn on the game over screen
    script.gameOverBg.enabled = true;
    
    // Play Game over music and correct its volume
    script.gameBGM.volume = 0.3;
    script.gameOverBGM.play(1);
    
    // Stop the background music
    script.gameBGM.stop(true);
}

// This funtion starts the game
function startGame(eventData)
{
    // Make the game be able to start if the game isn't active
    if(!playing)
    {
        // Set the game active
        playing = true;
        
        // Make it possible for all objects to move
        global.tweenManager.startTween(script.collision, "collision_move");
        global.tweenManager.startTween(script.bg1, "bg1_move");
        global.tweenManager.startTween(script.bg2, "bg2_move");
        
        // Choose a random collision image
        chooseCollision();
        
        // Turn off the game over screen
        script.gameOverBg.enabled = false;
        
        // Start the background music and correct its volume
        script.gameBGM.volume = 0.3;
        script.gameBGM.play(-1);
    }
}

// This function chooses a random image for the collision object
function chooseCollision()
{
    // Generate a random number from 0, 1 or 2
    randomNumber = Math.floor(Math.random() * Math.floor(3));
    
    // Enable the collision image that coresponds with the random number
    switch (randomNumber)
    {
        case 0:
            script.collisionImg1.enabled = true;
            script.collisionImg2.enabled = false;
            script.collisionImg3.enabled = false;
        break;
        case 1:
            script.collisionImg1.enabled = false;
            script.collisionImg2.enabled = true;
            script.collisionImg3.enabled = false;
        break;
        case 2:
            script.collisionImg1.enabled = false;
            script.collisionImg2.enabled = false;
            script.collisionImg3.enabled = true;
    }
}

// Bind events to the update and startgame functions
var event = script.createEvent("UpdateEvent");
var event2 = script.createEvent("TapEvent");

event.bind(update);
event2.bind(startGame);
